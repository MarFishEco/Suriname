var phases =
{type:"FeatureCollection",
features:[
{"type": "Feature", "properties": { "HRVST_CODE": 393 }, "geometry": { "type": "Polygon", "coordinates": [ [ [-55.22, 5.89], [-55.15, 5.89], [-55.15, 5.8], [-55.22, 5.8] ] ] } }]}